# Sample Spectrogram Dataset

## Overview

This folder contains 60 sample STFT spectrograms (15 per class) for reviewer verification of preprocessing quality.

## Dataset Statistics

| Class | Samples | Magnitude Range | Description |
|-------|---------|-----------------|-------------|
| Large | 15 | M6.0+ | Major earthquake precursors |
| Medium | 15 | M5.0-5.9 | Moderate earthquake precursors |
| Moderate | 15 | M4.0-4.9 | Minor earthquake precursors |
| Normal | 15 | N/A | Non-precursor baseline |

## Preprocessing Pipeline

1. **Raw Data**: 3-component (H, D, Z) geomagnetic time series at 1 Hz
2. **Bandpass Filter**: 0.001-0.5 Hz (Butterworth, order 4)
3. **Temporal Window**: 6-hour segments before earthquake events
4. **STFT Parameters**:
   - Window: Hanning, 256 samples
   - Overlap: 128 samples (50%)
   - FFT size: 512
5. **Image Generation**: 224x224 RGB spectrogram
6. **Normalization**: ImageNet mean/std

## File Naming Convention

```
{Class}_{Station}_{Date}_H{Hour}_3comp_spec.png

Example: Large_MLB_2021-04-16_H02_3comp_spec.png
- Class: Large (M6.0+)
- Station: MLB (Maluku)
- Date: 2021-04-16
- Hour: H02 (2 hours before event)
- Type: 3-component spectrogram
```

## Verification Checklist

- [ ] ULF band (0.001-0.01 Hz) visible in lower portion
- [ ] Clear frequency-time structure
- [ ] No obvious artifacts or noise
- [ ] Consistent color scaling across samples
- [ ] Temporal evolution patterns visible

## Data Access

Full dataset available upon request from corresponding author.
Raw geomagnetic data subject to BMKG data-sharing policies.
