# Extended Technical Implementation

## 1. Model Architecture Details

### 1.1 VGG16 Multi-Task Architecture

```
Input: 224x224x3 (RGB Spectrogram)
│
├── VGG16 Backbone (pretrained ImageNet)
│   ├── Conv Block 1: 64 filters, 3x3, stride 1
│   ├── Conv Block 2: 128 filters, 3x3, stride 1
│   ├── Conv Block 3: 256 filters, 3x3, stride 1
│   ├── Conv Block 4: 512 filters, 3x3, stride 1
│   └── Conv Block 5: 512 filters, 3x3, stride 1
│
├── Global Average Pooling
│
├── Shared FC Layer: 4096 → 512 (ReLU, Dropout 0.5)
│
├── Magnitude Head
│   └── FC: 512 → 4 (Softmax)
│
└── Azimuth Head
    └── FC: 512 → 9 (Softmax)

Total Parameters: 138,357,544 (528 MB)
```

### 1.2 EfficientNet-B0 Multi-Task Architecture

```
Input: 224x224x3 (RGB Spectrogram)
│
├── EfficientNet-B0 Backbone (pretrained ImageNet)
│   ├── Stem: Conv 3x3, 32 filters, stride 2
│   ├── MBConv1 (k3x3): 16 filters, expand 1
│   ├── MBConv6 (k3x3): 24 filters, expand 6, stride 2
│   ├── MBConv6 (k5x5): 40 filters, expand 6, stride 2
│   ├── MBConv6 (k3x3): 80 filters, expand 6, stride 2
│   ├── MBConv6 (k5x5): 112 filters, expand 6
│   ├── MBConv6 (k5x5): 192 filters, expand 6, stride 2
│   └── MBConv6 (k3x3): 320 filters, expand 6
│
├── Global Average Pooling → 1280 features
│
├── Shared FC Layer: 1280 → 512 (ReLU, Dropout 0.444)
│
├── Magnitude Head
│   └── FC: 512 → 4 (Softmax)
│
└── Azimuth Head
    └── FC: 512 → 9 (Softmax)

Total Parameters: 5,288,548 (20 MB)
```

## 2. Hyperparameter Tuning Results

### 2.1 Grid Search Configuration

| Parameter | Search Range | Best Value |
|-----------|--------------|------------|
| Learning Rate | [1e-5, 5e-5, 1e-4, 5e-4, 1e-3] | 9.89e-4 |
| Dropout Rate | [0.3, 0.4, 0.5, 0.6] | 0.444 |
| Batch Size | [16, 32, 64] | 32 |
| Weight Decay | [1e-5, 1e-4, 1e-3] | 1e-4 |
| Focal Loss γ | [1.0, 2.0, 3.0] | 2.0 |

### 2.2 Learning Rate Experiments

| Experiment | Learning Rate | Mag Acc | Azi Acc | Notes |
|------------|---------------|---------|---------|-------|
| exp_01 | 1e-5 | 89.23% | 45.12% | Underfitting |
| exp_02 | 5e-5 | 92.45% | 52.34% | Slow convergence |
| exp_03 | 1e-4 | 94.12% | 55.67% | Good |
| exp_04 | 5e-4 | 96.78% | 58.23% | Better |
| exp_05 | 9.89e-4 | 97.53% | 69.30% | **Best** |
| exp_06 | 1e-3 | 95.34% | 61.45% | Slight overfit |

### 2.3 Dropout Rate Experiments

| Dropout | Mag Acc | Azi Acc | Overfit Gap |
|---------|---------|---------|-------------|
| 0.3 | 98.12% | 71.23% | 8.5% |
| 0.4 | 97.89% | 70.45% | 5.2% |
| 0.444 | 97.53% | 69.30% | 3.8% |
| 0.5 | 96.78% | 67.89% | 2.1% |
| 0.6 | 94.56% | 63.45% | 1.2% |

Selected: **Dropout = 0.444** (optimal balance)

## 3. Training Configuration

```python
# Optimizer
optimizer = torch.optim.Adam(
    model.parameters(),
    lr=9.89e-4,
    weight_decay=1e-4
)

# Learning Rate Scheduler
scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
    optimizer,
    mode='min',
    factor=0.5,
    patience=5,
    min_lr=1e-6
)

# Loss Function
criterion = FocalLoss(gamma=2.0, alpha=class_weights)

# Early Stopping
early_stopping = EarlyStopping(patience=10, min_delta=0.001)
```
